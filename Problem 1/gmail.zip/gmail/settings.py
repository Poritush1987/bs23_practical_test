BASE_URL = 'https://www.alibaba.com/'
LOGIN_CREDENTIALS = {
    'email': 'test@email.com',
    'password': 'abcabc',
}
